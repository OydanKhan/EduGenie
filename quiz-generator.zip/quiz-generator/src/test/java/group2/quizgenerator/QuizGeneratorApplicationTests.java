package group2.quizgenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizGeneratorApplicationTests {

    @Test
    void contextLoads() {
    }

}
