package group2.quizgenerator;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class OpenAiService {

    private final String OPENAI_API_KEY = "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"; // Replace with your OpenAI API key

    public String generateQuiz(String topic) {
        RestTemplate restTemplate = new RestTemplate();

        // Headers for the request
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(OPENAI_API_KEY);

        // Prompt for quiz generation
        String requestBody = "{\n" +
                "    \"model\": \"text-davinci-003\",\n" +
                "    \"prompt\": \"Generate a 5-question quiz on the topic: " + topic + "\",\n" +
                "    \"max_tokens\": 300,\n" +
                "    \"temperature\": 0.7\n" +
                "}";

        HttpEntity<String> entity = new HttpEntity<>(requestBody, headers);

        // API URL for completions
        String apiUrl = "https://api.openai.com/v1/completions";

        // Make the request
        ResponseEntity<String> response = restTemplate.exchange(apiUrl, HttpMethod.POST, entity, String.class);

        // Return response body (OpenAI will return the quiz)
        return response.getBody();
    }
}
