package group2.quizgenerator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuizGeneratorApplication {

    public static void main(String[] args) {
        SpringApplication.run(QuizGeneratorApplication.class, args);
    }

}
