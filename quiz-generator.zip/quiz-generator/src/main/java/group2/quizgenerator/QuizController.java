package group2.quizgenerator;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class QuizController {

    private final OpenAiService OpenAiService;
    public QuizController(OpenAiService OpenAiService) {
        this.OpenAiService = OpenAiService;
    }

    @GetMapping("/api/quiz")
    public ResponseEntity<String> generateQuiz(@RequestParam String topic) {
        // Call the OpenAI service to generate the quiz
        String quiz =OpenAiService.generateQuiz(topic);
        return ResponseEntity.ok(quiz);
    }}
