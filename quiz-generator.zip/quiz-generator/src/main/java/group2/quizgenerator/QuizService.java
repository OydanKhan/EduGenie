package group2.quizgenerator;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import java.util.Collections; // Import this for shuffle
import java.util.List;

@Service
public class QuizService {

    // Injecting the QuestionRepository
    private final QuestionRepository questionRepository;

    public QuizService(QuestionRepository questionRepository) {
        this.questionRepository = questionRepository;
    }

    public List<Question> getAllQuestions() {
        return questionRepository.findAll();
    }

    public ResponseEntity<Quiz> generateQuiz(int numberOfQuestions) {
        List<Question> questions = questionRepository.findAll();

        // Shuffle and generate a quiz
        Collections.shuffle(questions);

        // Create a quiz with the shuffled questions, limiting to the requested number
        Quiz quiz = new Quiz(questions.subList(0, Math.min(numberOfQuestions, questions.size())));

        // Return the quiz wrapped in a ResponseEntity
        return ResponseEntity.ok(quiz);
    }
}
